const Settings = () => {
  return <div className="bg-white">Settings</div>;
};

export default Settings;
