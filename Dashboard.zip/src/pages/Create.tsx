const Create = () => {
  return <div className="bg-white">Create</div>;
};

export default Create;
